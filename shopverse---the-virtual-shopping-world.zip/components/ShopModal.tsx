
import React, { useState, useEffect } from 'react';
import { Shop, Product, Review, User, Message } from '../types';
import { db } from '../services/db';
import { gemini } from '../services/geminiService';

interface ShopModalProps {
  currentUser: User;
  shop: Shop;
  onClose: () => void;
  onAddToCart: (product: Product) => void;
  onChatWithOwner: () => void;
  onRefresh: () => void;
}

export const ShopModal: React.FC<ShopModalProps> = ({ currentUser, shop, onClose, onAddToCart, onChatWithOwner, onRefresh }) => {
  const [activeTab, setActiveTab] = useState<'PRODUCTS' | 'AI_ASSISTANT' | 'CART'>('PRODUCTS');
  const [activeCategory, setActiveCategory] = useState<string>('All');
  const [reviews, setReviews] = useState<Review[]>([]);
  const [newReview, setNewReview] = useState('');
  const [rating, setRating] = useState(5);
  const [isFollowing, setIsFollowing] = useState(false);
  const [aiChat, setAiChat] = useState<Message[]>([]);
  const [aiInput, setAiInput] = useState('');
  const [isAiTyping, setIsAiTyping] = useState(false);
  
  // Local temporary cart state
  const [cart, setCart] = useState<Product[]>([]);
  
  useEffect(() => {
    db.reviews.getByShopId(shop.id).then(setReviews);
    db.follows.isFollowing(currentUser.id, shop.ownerId).then(setIsFollowing);
    db.shops.recordVisit(shop.id); // Record traffic for rent calculation
  }, [shop.id, currentUser.id]);

  const handleLike = async () => {
    await db.shops.like(shop.id);
    onRefresh();
  };

  const handleFollow = async () => {
    await db.follows.toggleFollow(currentUser.id, shop.ownerId);
    setIsFollowing(!isFollowing);
  };

  const handleAddToCartLocal = (product: Product) => {
    setCart(prev => [...prev, product]);
    onAddToCart(product); // Trigger parent callback if needed
  };

  const removeFromCart = (productId: string) => {
    const index = cart.findIndex(p => p.id === productId);
    if (index > -1) {
      const newCart = [...cart];
      newCart.splice(index, 1);
      setCart(newCart);
    }
  };

  const cartTotal = cart.reduce((sum, item) => sum + item.price, 0);

  const handleAiChat = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!aiInput.trim()) return;

    const userMsg: Message = { id: Date.now().toString(), senderId: currentUser.id, receiverId: 'AI', text: aiInput, timestamp: Date.now() };
    setAiChat(prev => [...prev, userMsg]);
    setAiInput('');
    setIsAiTyping(true);

    const reply = await gemini.assistantResponse(shop.name, shop.assistantInstructions || "A high-end boutique.", shop.products, aiInput);
    
    setTimeout(() => {
      setAiChat(prev => [...prev, { id: (Date.now()+1).toString(), senderId: 'AI', receiverId: currentUser.id, text: reply, timestamp: Date.now(), isAI: true }]);
      setIsAiTyping(false);
    }, 1000);
  };

  const submitReview = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newReview.trim()) return;
    const review: Review = {
      id: Date.now().toString(),
      shopId: shop.id,
      userId: currentUser.id,
      userName: currentUser.name,
      rating,
      comment: newReview,
      timestamp: Date.now()
    };
    await db.reviews.create(review);
    setReviews([...reviews, review]);
    setNewReview('');
  };

  const categories = ['All', ...Array.from(new Set(shop.products.map(p => p.category)))];
  const filteredProducts = activeCategory === 'All' 
    ? shop.products 
    : shop.products.filter(p => p.category === activeCategory);

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm" onClick={onClose}></div>
      <div className="relative bg-white w-full max-w-5xl h-[85vh] rounded-3xl shadow-2xl flex overflow-hidden animate-in fade-in zoom-in">
        
        <div className="flex-1 flex flex-col">
            <div className={`p-8 ${shop.color} text-white relative`}>
                <div className="flex items-end gap-6">
                    <div className="w-20 h-20 bg-white/20 backdrop-blur rounded-2xl flex items-center justify-center text-3xl">🏪</div>
                    <div>
                        <h2 className="text-3xl font-black">{shop.name}</h2>
                        <div className="flex items-center gap-4 mt-2">
                            <button onClick={handleLike} className="flex items-center gap-1 bg-white/20 px-3 py-1 rounded-full text-xs font-bold hover:bg-white/40 transition-all">
                                ❤️ {shop.likes || 0}
                            </button>
                            <button onClick={handleFollow} className={`flex items-center gap-1 px-3 py-1 rounded-full text-xs font-bold transition-all ${isFollowing ? 'bg-white text-indigo-600' : 'bg-white/20 hover:bg-white/40'}`}>
                                {isFollowing ? 'Following' : 'Follow'}
                            </button>
                            <span className="text-white/60 text-xs font-bold uppercase tracking-widest">{shop.category}</span>
                        </div>
                    </div>
                </div>
                <div className="absolute top-6 right-6 flex gap-2">
                    <div className="flex bg-white/10 rounded-xl p-1 backdrop-blur-md border border-white/10">
                      <button 
                        onClick={() => setActiveTab('PRODUCTS')} 
                        className={`px-4 py-2 rounded-lg text-xs font-black transition-all ${activeTab === 'PRODUCTS' ? 'bg-white text-indigo-600' : 'text-white hover:bg-white/10'}`}
                      >
                        Products
                      </button>
                      <button 
                        onClick={() => setActiveTab('AI_ASSISTANT')} 
                        className={`px-4 py-2 rounded-lg text-xs font-black transition-all ${activeTab === 'AI_ASSISTANT' ? 'bg-white text-indigo-600' : 'text-white hover:bg-white/10'}`}
                      >
                        AI Help
                      </button>
                      <button 
                        onClick={() => setActiveTab('CART')} 
                        className={`px-4 py-2 rounded-lg text-xs font-black transition-all flex items-center gap-2 ${activeTab === 'CART' ? 'bg-white text-indigo-600' : 'text-white hover:bg-white/10'}`}
                      >
                        Cart ({cart.length})
                      </button>
                    </div>
                    <button onClick={onChatWithOwner} className="px-4 py-2 bg-indigo-500 text-white rounded-xl hover:bg-indigo-400 transition-all font-black text-xs shadow-lg">💬 Chat Owner</button>
                    <button onClick={onClose} className="p-2 bg-rose-500/20 text-white rounded-xl hover:bg-rose-500/40 transition-all font-black">✕</button>
                </div>
            </div>

            <div className="flex-1 overflow-y-auto bg-slate-50 relative">
                {activeTab === 'PRODUCTS' && (
                  <div className="p-8">
                    <div className="flex gap-2 mb-8 overflow-x-auto pb-2">
                      {categories.map(cat => (
                        <button 
                          key={cat} 
                          onClick={() => setActiveCategory(cat)}
                          className={`px-4 py-2 rounded-full text-xs font-bold whitespace-nowrap transition-all ${activeCategory === cat ? 'bg-indigo-600 text-white shadow-md' : 'bg-white text-slate-500 border hover:border-indigo-200'}`}
                        >
                          {cat}
                        </button>
                      ))}
                    </div>
                    <div className="grid grid-cols-2 lg:grid-cols-3 gap-6">
                      {filteredProducts.map(product => (
                        <div key={product.id} className="bg-white p-4 rounded-2xl shadow-sm hover:shadow-xl transition-all group border border-transparent hover:border-indigo-100">
                          <div className="aspect-square rounded-xl bg-slate-100 overflow-hidden mb-3 relative">
                            <img src={product.imageUrl} className="w-full h-full object-cover group-hover:scale-105 transition-transform" />
                            <div className="absolute top-2 right-2 px-2 py-1 bg-white/90 backdrop-blur rounded-lg text-[10px] font-black text-indigo-600 shadow-sm">
                              {product.category}
                            </div>
                          </div>
                          <h4 className="font-bold text-slate-800 line-clamp-1">{product.name}</h4>
                          <p className="text-indigo-600 font-black text-lg mb-3">${product.price}</p>
                          <button 
                            onClick={() => handleAddToCartLocal(product)} 
                            className="w-full py-2.5 bg-indigo-600 text-white rounded-xl font-bold text-sm shadow-md active:scale-95 transition-all hover:bg-indigo-700"
                          >
                            Add to Cart
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {activeTab === 'AI_ASSISTANT' && (
                  <div className="h-full flex flex-col p-8">
                    <div className="bg-indigo-50 p-6 rounded-3xl mb-6 border border-indigo-100 flex items-center gap-4">
                      <div className="w-12 h-12 bg-indigo-600 rounded-2xl flex items-center justify-center text-2xl text-white">🤖</div>
                      <div>
                        <h3 className="font-black text-indigo-900">Virtual Concierge</h3>
                        <p className="text-xs text-indigo-600 font-medium">Ask about stock, sizes, or custom requests.</p>
                      </div>
                    </div>
                    <div className="flex-1 overflow-y-auto space-y-4 mb-4 pr-2">
                        {aiChat.map(m => (
                          <div key={m.id} className={`flex ${m.senderId === currentUser.id ? 'justify-end' : 'justify-start'}`}>
                            <div className={`max-w-[70%] p-4 rounded-2xl text-sm ${m.isAI ? 'bg-indigo-100 text-indigo-900 rounded-bl-none shadow-sm' : 'bg-white text-slate-800 shadow-md border rounded-br-none'}`}>
                                {m.text}
                            </div>
                          </div>
                        ))}
                        {isAiTyping && <div className="text-xs text-indigo-400 font-bold animate-pulse flex items-center gap-2">
                          <span className="w-2 h-2 bg-indigo-400 rounded-full animate-bounce"></span>
                          AI is thinking...
                        </div>}
                    </div>
                    <form onSubmit={handleAiChat} className="flex gap-2">
                        <input 
                          value={aiInput} 
                          onChange={e => setAiInput(e.target.value)} 
                          placeholder="What would you like to know?" 
                          className="flex-1 p-4 rounded-xl border-2 border-slate-200 shadow-inner outline-none focus:border-indigo-500 transition-all font-medium" 
                        />
                        <button type="submit" className="bg-indigo-600 text-white px-8 rounded-xl font-black uppercase text-xs shadow-lg hover:bg-indigo-700 transition-all active:scale-95">Send</button>
                    </form>
                  </div>
                )}

                {activeTab === 'CART' && (
                  <div className="p-8 h-full flex flex-col">
                    <h3 className="text-2xl font-black text-slate-900 mb-6">Your Shopping Cart</h3>
                    <div className="flex-1 overflow-y-auto space-y-4 pr-2">
                      {cart.map((item, idx) => (
                        <div key={`${item.id}-${idx}`} className="bg-white p-4 rounded-2xl shadow-sm border flex items-center gap-4">
                          <img src={item.imageUrl} className="w-16 h-16 rounded-xl object-cover" />
                          <div className="flex-1">
                            <h4 className="font-bold text-slate-800">{item.name}</h4>
                            <p className="text-indigo-600 font-black">${item.price}</p>
                          </div>
                          <button 
                            onClick={() => removeFromCart(item.id)}
                            className="p-2 text-rose-500 hover:bg-rose-50 rounded-xl transition-all font-bold"
                          >
                            Remove
                          </button>
                        </div>
                      ))}
                      {cart.length === 0 && (
                        <div className="text-center py-20">
                          <div className="text-6xl mb-4 opacity-20">🛒</div>
                          <p className="text-slate-400 font-black uppercase tracking-widest">Your cart is empty</p>
                          <button onClick={() => setActiveTab('PRODUCTS')} className="mt-4 text-indigo-600 font-bold hover:underline">Start Shopping</button>
                        </div>
                      )}
                    </div>
                    {cart.length > 0 && (
                      <div className="mt-8 pt-8 border-t space-y-6">
                        <div className="flex justify-between items-center px-4">
                          <span className="text-slate-500 font-bold">Estimated Total:</span>
                          <span className="text-3xl font-black text-indigo-600">${cartTotal.toFixed(2)}</span>
                        </div>
                        <button className="w-full py-5 bg-indigo-600 text-white rounded-[2rem] font-black text-xl shadow-xl shadow-indigo-200 hover:bg-indigo-700 active:scale-95 transition-all">
                          Checkout Now
                        </button>
                      </div>
                    )}
                  </div>
                )}
            </div>
        </div>

        <div className="w-80 border-l bg-white flex flex-col">
            <div className="p-6 border-b bg-slate-50/50">
                <h3 className="font-black text-slate-900 uppercase tracking-widest text-[10px] mb-4 opacity-50">Community Reviews</h3>
                <form onSubmit={submitReview} className="space-y-3">
                    <textarea 
                        value={newReview}
                        onChange={e => setNewReview(e.target.value)}
                        placeholder="Share your experience..."
                        className="w-full p-4 bg-white rounded-2xl text-xs font-medium border border-slate-200 outline-none focus:ring-2 focus:ring-indigo-500/20 transition-all"
                    />
                    <div className="flex justify-between items-center">
                        <select value={rating} onChange={e => setRating(Number(e.target.value))} className="text-xs bg-transparent font-bold outline-none cursor-pointer">
                            <option value="5">⭐⭐⭐⭐⭐</option>
                            <option value="4">⭐⭐⭐⭐</option>
                            <option value="3">⭐⭐⭐</option>
                            <option value="2">⭐⭐</option>
                            <option value="1">⭐</option>
                        </select>
                        <button type="submit" className="bg-slate-900 text-white px-4 py-2 rounded-xl text-[10px] font-black uppercase shadow-lg active:scale-95 transition-all">Post</button>
                    </div>
                </form>
            </div>
            <div className="flex-1 overflow-y-auto p-6 space-y-6">
                {reviews.map(r => (
                    <div key={r.id} className="p-4 bg-slate-50 rounded-2xl space-y-1 hover:bg-slate-100 transition-colors">
                        <div className="flex justify-between">
                            <p className="font-black text-[10px] uppercase text-indigo-600">{r.userName}</p>
                            <span className="text-[8px] text-slate-400 font-bold uppercase">{new Date(r.timestamp).toLocaleDateString()}</span>
                        </div>
                        <p className="text-[10px] mb-2">{'⭐'.repeat(r.rating)}</p>
                        <p className="text-xs text-slate-600 font-medium leading-relaxed">{r.comment}</p>
                    </div>
                ))}
                {reviews.length === 0 && (
                  <div className="text-center py-10">
                    <p className="text-slate-400 text-[10px] font-bold uppercase tracking-widest">No reviews yet</p>
                  </div>
                )}
            </div>
        </div>
      </div>
    </div>
  );
};
