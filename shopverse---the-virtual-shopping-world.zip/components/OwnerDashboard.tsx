
import React, { useState, useMemo, useEffect } from 'react';
import { Shop, Product, Order, Message, Follow, RentTransaction, Notification, User } from '../types';
import { db } from '../services/db';

interface OwnerDashboardProps {
  shop: Shop | null;
  orders: Order[];
  allMessages: Message[];
  notifications: Notification[];
  onUpdateShop: (updatedShop: Shop) => void;
  onClose: () => void;
  onOpenChat: (userId: string) => void;
  onEnterMapMode: () => void;
  onSignOut: () => void;
}

type Tab = 'SETTINGS' | 'INVENTORY' | 'FINANCIALS' | 'MESSAGES' | 'AI_CONFIG' | 'EXPANSION';

export const OwnerDashboard: React.FC<OwnerDashboardProps> = ({ 
  shop, 
  orders, 
  allMessages,
  notifications, 
  onUpdateShop, 
  onClose,
  onOpenChat,
  onEnterMapMode,
  onSignOut
}) => {
  const [activeTab, setActiveTab] = useState<Tab>('SETTINGS');
  const [newProduct, setNewProduct] = useState<Partial<Product>>({ name: '', price: 0, description: '', category: 'General', imageUrl: '' });
  const [uploadingImage, setUploadingImage] = useState(false);
  const [followers, setFollowers] = useState<Follow[]>([]);
  const [rentHistory, setRentHistory] = useState<RentTransaction[]>([]);
  const [ownerBalance, setOwnerBalance] = useState(0);
  const [inventoryFilter, setInventoryFilter] = useState('All');
  const [customerDetails, setCustomerDetails] = useState<Record<string, User>>({});

  useEffect(() => {
    if (shop) {
      db.follows.getFollowers(shop.ownerId).then(setFollowers);
      db.rent.getHistory(shop.id).then(setRentHistory);
      db.users.getById(shop.ownerId).then(u => setOwnerBalance(u?.balance || 0));
    }
  }, [shop]);

  // Group conversations and fetch customer details
  const conversations = useMemo(() => {
    if (!shop) return [];
    const map = new Map<string, { lastMsg: Message, unreadCount: number }>();
    const ownerMessages = allMessages.filter(m => m.senderId === shop.ownerId || m.receiverId === shop.ownerId);
    
    ownerMessages.sort((a, b) => b.timestamp - a.timestamp).forEach(m => {
        const otherId = m.senderId === shop.ownerId ? m.receiverId : m.senderId;
        if (otherId === 'AI') return; // Ignore AI assistant messages
        
        if (!map.has(otherId)) {
            const unread = allMessages.filter(msg => msg.receiverId === shop.ownerId && msg.senderId === otherId && !msg.isRead).length;
            map.set(otherId, { lastMsg: m, unreadCount: unread });
        }
    });
    return Array.from(map.entries());
  }, [allMessages, shop?.ownerId]);

  // Fetch missing customer details
  useEffect(() => {
    const missingIds = conversations
      .map(([id]) => id)
      .filter(id => !customerDetails[id]);

    if (missingIds.length > 0) {
      Promise.all(missingIds.map(id => db.users.getById(id))).then(users => {
        const newDetails = { ...customerDetails };
        users.forEach(u => {
          if (u) newDetails[u.id] = u;
        });
        setCustomerDetails(newDetails);
      });
    }
  }, [conversations, customerDetails]);

  if (!shop) return null;

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setUploadingImage(true);
      const reader = new FileReader();
      reader.onloadend = () => {
        setNewProduct(prev => ({ ...prev, imageUrl: reader.result as string }));
        setUploadingImage(false);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleAddProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newProduct.imageUrl) {
        alert("Please upload a product image.");
        return;
    }
    const product: Product = {
      ...newProduct as Product,
      id: Math.random().toString(36).substr(2, 9),
      ownerId: shop.ownerId,
      timestamp: Date.now()
    };
    
    onUpdateShop({ ...shop, products: [...shop.products, product] });
    setNewProduct({ name: '', price: 0, description: '', category: 'General', imageUrl: '' });

    // Notify followers
    followers.forEach(async f => {
      await db.notifications.create({
        id: `notif_${Date.now()}_${f.shopperId}`,
        userId: f.shopperId,
        title: 'New Drop!',
        message: `${shop.name} just added "${product.name}" to their catalogue!`,
        type: 'SUCCESS',
        timestamp: Date.now(),
        isRead: false
      });
    });
  };

  const removeProduct = (id: string) => {
    onUpdateShop({ ...shop, products: shop.products.filter(p => p.id !== id) });
  };

  const handleCollectRent = async () => {
    const amount = await db.rent.collectRent(shop.id);
    if (amount > 0) {
      const history = await db.rent.getHistory(shop.id);
      setRentHistory(history);
      const u = await db.users.getById(shop.ownerId);
      setOwnerBalance(u?.balance || 0);
      alert(`Paid $${amount} in dynamic rent based on your location's traffic.`);
    } else {
      alert("No rent due yet or no traffic recorded.");
    }
  };

  const categories = ['All', ...Array.from(new Set(shop.products.map(p => p.category || 'General')))];
  const filteredProducts = inventoryFilter === 'All' 
    ? shop.products 
    : shop.products.filter(p => (p.category || 'General') === inventoryFilter);

  return (
    <div className="fixed inset-0 z-[3000] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-slate-900/80 backdrop-blur-md" onClick={onClose}></div>
      <div className="relative bg-white w-full max-w-6xl h-[90vh] rounded-[3rem] shadow-2xl flex overflow-hidden animate-in zoom-in duration-300">
        
        <div className="w-72 bg-slate-50 border-r p-8 flex flex-col">
          <div className="mb-12">
            <h2 className="text-2xl font-black text-slate-900 leading-none mb-1">Business Center</h2>
            <p className="text-[10px] font-black text-indigo-500 uppercase tracking-widest">{shop.name}</p>
            <div className="mt-4 flex gap-4">
               <div className="text-center">
                  <p className="text-[8px] font-black text-slate-400 uppercase">Followers</p>
                  <p className="font-black text-indigo-600">{followers.length}</p>
               </div>
               <div className="text-center">
                  <p className="text-[8px] font-black text-slate-400 uppercase">Balance</p>
                  <p className="font-black text-emerald-600">${ownerBalance}</p>
               </div>
            </div>
          </div>
          
          <nav className="space-y-3 flex-1 overflow-y-auto pr-2">
            {[
              { id: 'SETTINGS', label: 'Branding', icon: '✨' },
              { id: 'INVENTORY', label: 'Catalogue', icon: '🛍️' },
              { id: 'FINANCIALS', label: 'Rent & Ledger', icon: '💰' },
              { id: 'MESSAGES', label: 'Customer CRM', icon: '💬', badge: conversations.reduce((acc, [, {unreadCount}]) => acc + unreadCount, 0) },
              { id: 'AI_CONFIG', label: 'AI Assistant', icon: '🤖' },
              { id: 'EXPANSION', label: 'Real Estate', icon: '🏢' }
            ].map(item => (
              <button key={item.id} onClick={() => setActiveTab(item.id as Tab)} className={`w-full flex items-center justify-between px-5 py-4 rounded-2xl text-xs font-bold transition-all ${activeTab === item.id ? 'bg-indigo-600 text-white shadow-xl' : 'text-slate-500 hover:bg-white hover:shadow-sm'}`}>
                <span className="flex items-center gap-4"><span className="text-lg">{item.icon}</span> {item.label}</span>
                {item.badge ? <span className={`px-2 py-0.5 rounded-full text-[10px] font-black ${activeTab === item.id ? 'bg-white text-indigo-600' : 'bg-rose-500 text-white'}`}>{item.badge}</span> : null}
              </button>
            ))}
          </nav>

          <div className="space-y-3 mt-auto">
              <button onClick={onClose} className="w-full py-4 bg-slate-900 text-white rounded-2xl font-black text-xs uppercase tracking-widest">World View</button>
              <button onClick={onSignOut} className="w-full py-3 text-rose-500 font-bold text-xs uppercase tracking-widest">Sign Out</button>
          </div>
        </div>

        <div className="flex-1 flex flex-col bg-white overflow-hidden">
          <div className="p-8 border-b flex justify-between items-center">
            <h3 className="text-3xl font-black text-slate-900">{activeTab.replace(/_/g, ' ')}</h3>
            {activeTab === 'FINANCIALS' && <button onClick={handleCollectRent} className="bg-indigo-600 text-white px-6 py-3 rounded-xl font-bold text-xs">Pay Due Rent</button>}
          </div>

          <div className="flex-1 overflow-y-auto p-10">
            {activeTab === 'SETTINGS' && (
              <div className="max-w-3xl space-y-10">
                <div className="bg-slate-50 p-10 rounded-[2.5rem] border space-y-8">
                    <div className="grid grid-cols-2 gap-6">
                        <div className="space-y-2">
                          <p className="text-[10px] font-bold text-slate-400">Trade Name</p>
                          <input type="text" value={shop.name} onChange={(e) => onUpdateShop({ ...shop, name: e.target.value })} className="w-full p-4 rounded-2xl bg-white shadow-sm font-bold" />
                        </div>
                        <div className="space-y-2">
                          <p className="text-[10px] font-bold text-slate-400">Category</p>
                          <select value={shop.category} onChange={(e) => onUpdateShop({ ...shop, category: e.target.value })} className="w-full p-4 rounded-2xl bg-white shadow-sm font-bold">
                            <option>Fashion</option><option>Electronics</option><option>Cafe</option><option>Art</option><option>General</option>
                          </select>
                        </div>
                    </div>
                </div>
              </div>
            )}

            {activeTab === 'MESSAGES' && (
              <div className="space-y-4">
                {conversations.length === 0 && (
                   <div className="text-center py-20 bg-slate-50 rounded-[3rem]">
                      <div className="text-4xl mb-4">📭</div>
                      <p className="text-slate-400 font-bold uppercase text-xs tracking-widest">No customer conversations yet</p>
                   </div>
                )}
                {conversations.map(([userId, { lastMsg, unreadCount }]) => {
                  const customer = customerDetails[userId];
                  return (
                    <button 
                      key={userId} 
                      onClick={() => onOpenChat(userId)}
                      className="w-full text-left p-6 bg-white border rounded-[2rem] hover:shadow-lg transition-all flex items-center gap-6 group"
                    >
                      <div className="relative">
                        <img src={customer?.avatarUrl || `https://picsum.photos/seed/${userId}/100`} className="w-16 h-16 rounded-full border-2 border-slate-100" />
                        {unreadCount > 0 && <span className="absolute -top-1 -right-1 w-6 h-6 bg-rose-500 text-white text-[10px] font-black rounded-full flex items-center justify-center border-2 border-white">{unreadCount}</span>}
                      </div>
                      <div className="flex-1">
                        <div className="flex justify-between items-center mb-1">
                          <h4 className="font-black text-slate-900">{customer?.name || 'Loading Customer...'}</h4>
                          <span className="text-[10px] text-slate-400 font-bold uppercase">{new Date(lastMsg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                        </div>
                        <p className="text-sm text-slate-500 line-clamp-1 font-medium">{lastMsg.senderId === shop.ownerId ? 'You: ' : ''}{lastMsg.text}</p>
                      </div>
                      <div className="w-10 h-10 bg-indigo-50 text-indigo-600 rounded-xl flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                         <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M14 5l7 7m0 0l-7 7m7-7H3" /></svg>
                      </div>
                    </button>
                  );
                })}
              </div>
            )}

            {activeTab === 'FINANCIALS' && (
              <div className="space-y-6">
                <div className="bg-indigo-50 p-8 rounded-[2rem] border border-indigo-100 mb-8">
                   <h4 className="font-black text-indigo-900 mb-2 uppercase text-xs">Dynamic Rent Model</h4>
                   <p className="text-indigo-600 text-sm">Rent is calculated as 5% of base land value + $0.50 per visitor. High traffic plots cost more!</p>
                </div>
                <div className="bg-white border rounded-[2rem] overflow-hidden">
                  <table className="w-full text-left">
                    <thead className="bg-slate-50 text-[10px] font-black uppercase text-slate-400">
                      <tr><th className="p-6">Timestamp</th><th className="p-6">Reason</th><th className="p-6 text-right">Debit</th></tr>
                    </thead>
                    <tbody className="text-sm font-medium text-slate-600">
                      {rentHistory.map(r => (
                        <tr key={r.id} className="border-t"><td className="p-6">{new Date(r.timestamp).toLocaleString()}</td><td className="p-6">{r.reason}</td><td className="p-6 text-right text-rose-500 font-bold">-${r.amount}</td></tr>
                      ))}
                    </tbody>
                  </table>
                  {rentHistory.length === 0 && <p className="p-10 text-center text-slate-400 italic">No ledger entries</p>}
                </div>
              </div>
            )}

            {activeTab === 'AI_CONFIG' && (
               <div className="max-w-2xl space-y-6">
                 <div className="bg-slate-50 p-8 rounded-[2rem] border">
                    <h4 className="font-black text-slate-900 mb-4">Shop Assistant Brain</h4>
                    <p className="text-sm text-slate-500 mb-6">Describe your shop's vibe, policies, and specialties. Our Gemini AI will use this to chat with customers when they need help.</p>
                    <textarea 
                      value={shop.assistantInstructions || ''} 
                      onChange={e => onUpdateShop({...shop, assistantInstructions: e.target.value})}
                      placeholder="e.g. We are a luxury watch brand. We offer 2 year warranty on everything. We have a relaxed and posh atmosphere..."
                      className="w-full p-6 rounded-2xl h-48 outline-none border-2 focus:border-indigo-500 transition-all font-medium text-slate-700"
                    />
                 </div>
               </div>
            )}

            {activeTab === 'INVENTORY' && (
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
                <div className="lg:col-span-4 bg-slate-50 p-8 rounded-[2rem] h-fit">
                  <h4 className="text-xl font-black text-slate-900 mb-8">New Product</h4>
                  <form onSubmit={handleAddProduct} className="space-y-4">
                    <div className="aspect-square rounded-3xl bg-white border-4 border-dashed overflow-hidden relative group">
                      {newProduct.imageUrl ? <img src={newProduct.imageUrl} className="w-full h-full object-cover" /> : <div className="absolute inset-0 flex items-center justify-center text-slate-300 font-black uppercase text-xs text-center px-4">Tap to upload Image</div>}
                      <input type="file" accept="image/*" onChange={handleImageUpload} className="absolute inset-0 opacity-0 cursor-pointer" />
                    </div>
                    <div className="space-y-1">
                      <p className="text-[10px] font-black text-slate-400 uppercase ml-1">Product Details</p>
                      <input required placeholder="Name" value={newProduct.name} onChange={e => setNewProduct({...newProduct, name: e.target.value})} className="w-full p-4 rounded-xl border shadow-sm font-bold" />
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                       <input required type="number" placeholder="Price ($)" value={newProduct.price || ''} onChange={e => setNewProduct({...newProduct, price: Number(e.target.value)})} className="w-full p-4 rounded-xl border shadow-sm font-bold" />
                       <input placeholder="Category" value={newProduct.category} onChange={e => setNewProduct({...newProduct, category: e.target.value})} className="w-full p-4 rounded-xl border shadow-sm font-bold" />
                    </div>
                    <button type="submit" disabled={uploadingImage} className="w-full py-4 bg-indigo-600 text-white font-black rounded-xl hover:bg-indigo-700 transition-all uppercase text-xs shadow-lg shadow-indigo-200">Launch to Followers</button>
                  </form>
                </div>
                <div className="lg:col-span-8 space-y-6">
                  <div className="flex gap-2 mb-6 overflow-x-auto pb-2">
                    {categories.map(cat => (
                      <button 
                        key={cat} 
                        onClick={() => setInventoryFilter(cat)}
                        className={`px-4 py-2 rounded-full text-[10px] font-black uppercase tracking-widest transition-all ${inventoryFilter === cat ? 'bg-indigo-600 text-white shadow-md' : 'bg-slate-100 text-slate-500 hover:bg-slate-200'}`}
                      >
                        {cat}
                      </button>
                    ))}
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {filteredProducts.map(p => (
                      <div key={p.id} className="bg-white p-4 rounded-3xl border flex items-center gap-4 group hover:shadow-md transition-all">
                        <img src={p.imageUrl} className="w-20 h-20 rounded-2xl object-cover" />
                        <div className="flex-1">
                          <p className="text-[8px] font-black text-indigo-400 uppercase mb-1">{p.category || 'General'}</p>
                          <h5 className="font-black text-slate-800 line-clamp-1">{p.name}</h5>
                          <p className="font-black text-indigo-600">${p.price}</p>
                        </div>
                        <button onClick={() => removeProduct(p.id)} className="p-2 text-rose-500 hover:bg-rose-50 rounded-xl transition-all">✕</button>
                      </div>
                    ))}
                  </div>
                  {filteredProducts.length === 0 && (
                    <div className="text-center py-20 border-2 border-dashed rounded-[3rem]">
                       <p className="text-slate-400 font-bold uppercase text-xs tracking-widest">No items in this category</p>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
