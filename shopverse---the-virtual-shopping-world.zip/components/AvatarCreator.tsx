
import React, { useState } from 'react';
import { gemini } from '../services/geminiService';

interface AvatarCreatorProps {
  onAvatarComplete: (url: string) => void;
}

export const AvatarCreator: React.FC<AvatarCreatorProps> = ({ onAvatarComplete }) => {
  const [isGenerating, setIsGenerating] = useState(false);
  const [image, setImage] = useState<string | null>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const generateAvatar = async () => {
    if (!image) return;
    setIsGenerating(true);
    try {
      const base64 = image.split(',')[1];
      const desc = await gemini.generateAvatarDescription(base64);
      const avatarUrl = await gemini.generateAvatarImage(desc);
      onAvatarComplete(avatarUrl);
    } catch (error) {
      alert("Error generating avatar. Using default.");
      onAvatarComplete(`https://picsum.photos/seed/${Math.random()}/200`);
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="flex flex-col items-center justify-center p-8 bg-white rounded-3xl shadow-xl space-y-6 max-w-md w-full">
      <h2 className="text-3xl font-bold text-slate-800">Create Your Avatar</h2>
      <p className="text-slate-500 text-center">Upload a selfie and our AI will craft a personalized 3D shopping avatar for you.</p>
      
      <div className="relative group w-48 h-48 rounded-full bg-slate-100 flex items-center justify-center overflow-hidden border-4 border-indigo-100">
        {image ? (
          <img src={image} className="w-full h-full object-cover" alt="Preview" />
        ) : (
          <div className="text-center text-slate-400">
            <svg className="w-12 h-12 mx-auto mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" /></svg>
            <span>No Photo</span>
          </div>
        )}
        <label className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center cursor-pointer text-white text-sm font-semibold">
          Choose Photo
          <input type="file" className="hidden" accept="image/*" onChange={handleFileChange} />
        </label>
      </div>

      <button
        onClick={generateAvatar}
        disabled={!image || isGenerating}
        className={`w-full py-4 px-6 rounded-2xl font-bold text-lg transition-all ${
          !image || isGenerating 
            ? 'bg-slate-200 text-slate-400 cursor-not-allowed' 
            : 'bg-indigo-600 text-white hover:bg-indigo-700 shadow-lg hover:shadow-indigo-200'
        }`}
      >
        {isGenerating ? (
          <span className="flex items-center justify-center">
            <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>
            Generating Magic...
          </span>
        ) : 'Generate Avatar'}
      </button>
    </div>
  );
};
