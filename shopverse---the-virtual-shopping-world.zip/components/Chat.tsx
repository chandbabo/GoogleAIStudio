
import React, { useState, useEffect, useRef } from 'react';
import { User, Message, UserRole } from '../types';
import { gemini } from '../services/geminiService';

interface ChatProps {
  currentUser: User;
  targetUser: User;
  onClose: () => void;
  initialMessages?: Message[];
  shopContext?: string;
  onNewMessage?: (msg: Message) => void;
}

export const Chat: React.FC<ChatProps> = ({ currentUser, targetUser, onClose, initialMessages = [], shopContext, onNewMessage }) => {
  const [messages, setMessages] = useState<Message[]>(initialMessages);
  const [inputText, setInputText] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isTyping]);

  // Sync with prop updates if needed
  useEffect(() => {
    if (initialMessages.length > messages.length) {
        setMessages(initialMessages);
    }
  }, [initialMessages]);

  const sendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim()) return;

    const userMsg: Message = {
      id: Date.now().toString(),
      senderId: currentUser.id,
      receiverId: targetUser.id,
      text: inputText,
      timestamp: Date.now(),
      isRead: false
    };

    setMessages(prev => [...prev, userMsg]);
    if (onNewMessage) onNewMessage(userMsg);
    
    setInputText('');
    
    // Simulate Gemini response with appropriate persona
    setIsTyping(true);
    const history = messages.map(m => ({
        role: m.senderId === currentUser.id ? 'user' : 'model',
        parts: [{ text: m.text }]
    }));
    
    // Determine the system prompt based on whether target is an owner
    let systemPrompt = "You are a friendly fellow shopper in a virtual world called ShopVerse. Keep responses brief and conversational.";
    if (targetUser.role === UserRole.OWNER) {
      systemPrompt = `You are the owner of a shop called "${shopContext || 'My Store'}" in ShopVerse. 
      A customer is messaging you. You are professional, helpful, and willing to take custom orders for things not on your product list. 
      Keep responses brief and sales-oriented. If they ask for something not in stock, offer to make a special order.`;
    }
    
    try {
      const replyText = await gemini.chatResponse(history, inputText, systemPrompt);
      
      setTimeout(() => {
          const replyMsg: Message = {
              id: (Date.now() + 1).toString(),
              senderId: targetUser.id,
              receiverId: currentUser.id,
              text: replyText,
              timestamp: Date.now(),
              isRead: false
          };
          setMessages(prev => [...prev, replyMsg]);
          if (onNewMessage) onNewMessage(replyMsg);
          setIsTyping(false);
      }, 1500);
    } catch (err) {
      setIsTyping(false);
    }
  };

  return (
    <div className="fixed bottom-4 right-4 z-[70] w-96 h-[500px] bg-white rounded-3xl shadow-2xl flex flex-col overflow-hidden border border-slate-200 animate-in slide-in-from-bottom-10 duration-300">
      <div className="p-4 bg-slate-900 text-white flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="relative">
            <img src={targetUser.avatarUrl} className="w-10 h-10 rounded-full border-2 border-indigo-400" alt={targetUser.name} />
            <span className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 border-2 border-slate-900 rounded-full"></span>
          </div>
          <div>
            <p className="font-bold text-sm leading-none mb-1">{targetUser.name}</p>
            <p className="text-[10px] text-white/60 font-black uppercase tracking-widest">
              {targetUser.role === UserRole.OWNER ? 'Store Owner' : 'Shopper'}
            </p>
          </div>
        </div>
        <button onClick={onClose} className="p-1.5 hover:bg-white/10 rounded-full transition-colors">
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" /></svg>
        </button>
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-slate-50" ref={scrollRef}>
        {messages.length === 0 && (
          <div className="text-center py-10 flex flex-col items-center">
            <div className="w-12 h-12 bg-indigo-50 rounded-2xl flex items-center justify-center text-indigo-600 mb-3">
               <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" /></svg>
            </div>
            <p className="text-slate-400 text-sm font-medium px-8 text-center">
              {targetUser.role === UserRole.OWNER 
                ? `Welcome! You are chatting with the owner of ${shopContext}. Ask for custom orders or item details!`
                : `Say hi to ${targetUser.name}!`
              }
            </p>
          </div>
        )}
        {messages.map(m => (
          <div key={m.id} className={`flex ${m.senderId === currentUser.id ? 'justify-end' : 'justify-start'}`}>
            <div className={`max-w-[80%] px-4 py-2 rounded-2xl text-sm shadow-sm ${
              m.senderId === currentUser.id ? 'bg-indigo-600 text-white rounded-br-none' : 'bg-white text-slate-800 rounded-bl-none'
            }`}>
              {m.text}
            </div>
          </div>
        ))}
        {isTyping && (
          <div className="flex justify-start">
            <div className="bg-white px-4 py-2 rounded-2xl rounded-bl-none text-slate-400 flex gap-1 items-center shadow-sm border border-slate-100">
                <span className="w-1.5 h-1.5 bg-indigo-200 rounded-full animate-bounce"></span>
                <span className="w-1.5 h-1.5 bg-indigo-200 rounded-full animate-bounce delay-100"></span>
                <span className="w-1.5 h-1.5 bg-indigo-200 rounded-full animate-bounce delay-200"></span>
            </div>
          </div>
        )}
      </div>

      <form onSubmit={sendMessage} className="p-4 bg-white border-t flex gap-2">
        <input 
          type="text" 
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
          placeholder={targetUser.role === UserRole.OWNER ? "Ask for a custom order..." : "Type a message..."}
          className="flex-1 bg-slate-100 border-none rounded-xl px-4 py-2 text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
        />
        <button type="submit" className="bg-indigo-600 text-white p-2 rounded-xl hover:bg-indigo-700 transition-colors shadow-md active:scale-95">
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M14 5l7 7m0 0l-7 7m7-7H3" /></svg>
        </button>
      </form>
    </div>
  );
};
