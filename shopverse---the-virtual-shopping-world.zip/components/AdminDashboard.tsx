
import React, { useState, useEffect, useCallback } from 'react';
import { db } from '../services/db';
import { Shop, Market } from '../types';

interface AdminDashboardProps {
  onClose: () => void;
  onRefresh: () => void;
  onEstablishMarket: (name: string, lat: number, lng: number) => void;
  userCoords: { lat: number, lng: number } | null;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({ onClose, onRefresh, onEstablishMarket, userCoords }) => {
  const [activeTab, setActiveTab] = useState<'REQUESTS' | 'SHOPS' | 'MARKETS'>('REQUESTS');
  
  // Fix: Property 'all' does not exist on type. Using state and useEffect for async data fetching from db service.
  const [shops, setShops] = useState<Shop[]>([]);
  const [markets, setMarkets] = useState<Market[]>([]);

  // Memoized data loader to sync local state with db
  const loadData = useCallback(async () => {
    const allShops = await db.shops.getAll();
    const allMarkets = await db.markets.getAll();
    setShops(allShops);
    setMarkets(allMarkets);
  }, []);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const pendingRequests = shops.filter(s => s.status === 'PENDING');

  // Fix: db.shops.update is async, added await and local state refresh
  const handleApprove = async (shopId: string) => {
    await db.shops.update(shopId, { status: 'APPROVED', isActive: true });
    await loadData();
    onRefresh();
  };

  // Fix: db.shops.update is async, added await and local state refresh
  const handleReject = async (shopId: string) => {
    await db.shops.update(shopId, { status: 'REJECTED' });
    await loadData();
    onRefresh();
  };

  // Fix: db.shops.update is async, added await and local state refresh
  const handleToggleActive = async (shop: Shop) => {
    await db.shops.update(shop.id, { isActive: !shop.isActive });
    await loadData();
    onRefresh();
  };

  return (
    <div className="fixed inset-0 z-[3000] flex items-center justify-center p-6">
      <div className="absolute inset-0 bg-slate-950/90 backdrop-blur-xl" onClick={onClose}></div>
      <div className="relative bg-white w-full max-w-5xl h-[85vh] rounded-[3rem] shadow-2xl flex flex-col overflow-hidden animate-in zoom-in">
        
        <div className="p-8 border-b bg-slate-50 flex items-center justify-between">
           <div className="flex items-center gap-6">
              <h2 className="text-3xl font-black text-slate-900">Verse Admin</h2>
              <nav className="flex gap-2">
                {[
                  { id: 'REQUESTS', label: 'Approvals', count: pendingRequests.length },
                  { id: 'SHOPS', label: 'All Stores' },
                  { id: 'MARKETS', label: 'Districts' }
                ].map(tab => (
                  <button 
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id as any)}
                    className={`px-5 py-2 rounded-full text-xs font-black uppercase tracking-widest transition-all ${
                        activeTab === tab.id ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-slate-600'
                    }`}
                  >
                    {tab.label} {tab.count ? `(${tab.count})` : ''}
                  </button>
                ))}
              </nav>
           </div>
           <button onClick={onClose} className="p-2 bg-white rounded-2xl shadow-sm hover:bg-slate-50">
             <svg className="w-6 h-6 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M6 18L18 6M6 6l12 12" /></svg>
           </button>
        </div>

        <div className="flex-1 overflow-y-auto p-10">
          {activeTab === 'REQUESTS' && (
            <div className="space-y-6">
              {pendingRequests.map(s => (
                <div key={s.id} className="p-8 bg-slate-50 rounded-[2.5rem] border flex items-center justify-between">
                  <div className="flex items-center gap-6">
                     <div className={`w-16 h-16 ${s.color} rounded-2xl flex items-center justify-center text-3xl`}>🏪</div>
                     <div>
                        <h4 className="text-xl font-black text-slate-900">{s.name}</h4>
                        <p className="text-sm font-bold text-slate-400 uppercase tracking-widest">{s.category} • Plot {s.plotId}</p>
                     </div>
                  </div>
                  <div className="flex gap-3">
                     <button onClick={() => handleApprove(s.id)} className="px-6 py-3 bg-emerald-500 text-white rounded-2xl font-black text-xs uppercase tracking-widest shadow-lg shadow-emerald-500/20">Approve</button>
                     <button onClick={() => handleReject(s.id)} className="px-6 py-3 bg-rose-100 text-rose-500 rounded-2xl font-black text-xs uppercase tracking-widest">Reject</button>
                  </div>
                </div>
              ))}
              {pendingRequests.length === 0 && (
                <div className="text-center py-20 text-slate-300 font-black uppercase text-sm tracking-widest">No pending shop requests</div>
              )}
            </div>
          )}

          {activeTab === 'SHOPS' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {shops.map(s => (
                <div key={s.id} className="p-6 bg-white border rounded-[2rem] flex items-center justify-between group hover:shadow-xl transition-all">
                  <div className="flex items-center gap-4">
                     <div className={`w-12 h-12 ${s.color} rounded-xl flex items-center justify-center text-xl`}>🏪</div>
                     <div>
                        <p className="font-black text-slate-900">{s.name}</p>
                        <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{s.status}</p>
                     </div>
                  </div>
                  <button 
                    onClick={() => handleToggleActive(s)}
                    className={`px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest border transition-all ${
                      s.isActive ? 'border-emerald-200 text-emerald-500 bg-emerald-50' : 'border-rose-200 text-rose-500 bg-rose-50'
                    }`}
                  >
                    {s.isActive ? 'Active' : 'Deactivated'}
                  </button>
                </div>
              ))}
            </div>
          )}

          {activeTab === 'MARKETS' && (
            <div className="space-y-10">
              <div className="bg-slate-900 text-white p-10 rounded-[3rem] shadow-2xl">
                 <h3 className="text-2xl font-black mb-6">New District Clearance</h3>
                 <div className="grid grid-cols-2 gap-6 mb-8">
                    <input id="m_name" placeholder="District Name" className="w-full p-5 bg-white/10 rounded-2xl outline-none font-bold text-lg border-none" />
                    <div className="grid grid-cols-2 gap-4">
                        <input id="m_lat" type="number" step="0.000001" defaultValue={userCoords?.lat || 31.52} placeholder="Lat" className="w-full p-5 bg-white/10 rounded-2xl outline-none font-bold text-lg border-none" />
                        <input id="m_lng" type="number" step="0.000001" defaultValue={userCoords?.lng || 74.32} placeholder="Lng" className="w-full p-5 bg-white/10 rounded-2xl outline-none font-bold text-lg border-none" />
                    </div>
                 </div>
                 <button onClick={() => {
                    const name = (document.getElementById('m_name') as HTMLInputElement).value;
                    const lat = parseFloat((document.getElementById('m_lat') as HTMLInputElement).value);
                    const lng = parseFloat((document.getElementById('m_lng') as HTMLInputElement).value);
                    if (name && !isNaN(lat) && !isNaN(lng)) onEstablishMarket(name, lat, lng);
                 }} className="w-full py-5 bg-indigo-600 text-white rounded-2xl font-black text-lg">Inaugurate District</button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {markets.map(m => (
                  <div key={m.id} className="p-6 bg-slate-50 border rounded-3xl">
                    <p className="font-black text-slate-900 text-lg mb-1">{m.name}</p>
                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{m.lat.toFixed(4)}, {m.lng.toFixed(4)}</p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
