
import React, { useEffect, useRef, useState } from 'react';
import { User, Shop, Plot, UserRole, Market } from '../types';

interface VirtualWorldProps {
  currentUser: User;
  onOpenShop: (shop: Shop) => void;
  onOpenChat: (user: User) => void;
  shops: Shop[];
  plots: Plot[];
  otherUsers: User[];
  isSelectingPlot?: boolean;
  onSelectPlot?: (plot: Plot) => void;
  navigateTo?: { x: number, y: number } | null;
  activeMarket: Market | null;
}

declare const L: any; // Leaflet global

export const VirtualWorld: React.FC<VirtualWorldProps> = ({ 
  currentUser, 
  onOpenShop, 
  onOpenChat,
  shops,
  plots,
  otherUsers,
  isSelectingPlot = false,
  onSelectPlot,
  activeMarket
}) => {
  const mapRef = useRef<any>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const shopsMarkersRef = useRef<{ [key: string]: any }>({});
  const usersMarkersRef = useRef<{ [key: string]: any }>({});
  const plotsLayerRef = useRef<any>(null);
  const userMarkerRef = useRef<any>(null);
  const themeLayerRef = useRef<any>(null);
  const lastActiveMarketId = useRef<string | null>(null);

  useEffect(() => {
    if (!containerRef.current || mapRef.current) return;

    mapRef.current = L.map(containerRef.current, {
      zoomControl: true,
      attributionControl: false,
      dragging: true,
      scrollWheelZoom: true,
      touchZoom: true,
      doubleClickZoom: true,
      boxZoom: true,
      keyboard: true,
      fadeAnimation: true,
      markerZoomAnimation: true
    }).setView([31.52, 74.32], 15);

    L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', {
      maxZoom: 20
    }).addTo(mapRef.current);

    setTimeout(() => {
      if (mapRef.current) mapRef.current.invalidateSize();
    }, 100);

    return () => {
      if (mapRef.current) {
        mapRef.current.remove();
        mapRef.current = null;
      }
    };
  }, []);

  // Fly to market only when activeMarket.id actually changes
  useEffect(() => {
    if (activeMarket && mapRef.current && activeMarket.id !== lastActiveMarketId.current) {
      lastActiveMarketId.current = activeMarket.id;
      mapRef.current.flyTo([activeMarket.lat, activeMarket.lng], 16, { duration: 1.5 });
      
      // Market Festival Themes
      if (themeLayerRef.current) mapRef.current.removeLayer(themeLayerRef.current);
      
      if (activeMarket.eventTheme && activeMarket.eventTheme !== 'NORMAL') {
        const color = activeMarket.eventTheme === 'NEON' ? '#6366f1' : 
                      activeMarket.eventTheme === 'FESTIVE' ? '#f43f5e' : '#fbbf24';
        
        themeLayerRef.current = L.circle([activeMarket.lat, activeMarket.lng], {
          radius: 400,
          color: color,
          fillColor: color,
          fillOpacity: 0.1,
          dashArray: '10, 10',
          className: 'animate-pulse'
        }).addTo(mapRef.current);
      }
    }
  }, [activeMarket?.id]);

  // Stable Shop Markers
  useEffect(() => {
    if (!mapRef.current) return;
    
    // Clear existing
    // Fix: Cast to any to avoid "unknown" type error on remove() method when iterating values
    Object.values(shopsMarkersRef.current).forEach(m => (m as any).remove());
    shopsMarkersRef.current = {};

    shops.forEach(shop => {
      const icon = L.divIcon({
        className: 'custom-div-icon',
        html: `
          <div class="group flex flex-col items-center -translate-y-1/2 cursor-pointer pointer-events-auto">
            <div class="w-14 h-14 ${shop.color} rounded-[1.25rem] shadow-2xl flex items-center justify-center border-4 border-white transform hover:scale-110 transition-all duration-300 relative">
                ${activeMarket?.eventTheme === 'NEON' ? '<span class="absolute inset-0 rounded-2xl ring-4 ring-indigo-400/50 animate-ping"></span>' : ''}
                <span class="text-2xl">${shop.isActive ? '🏪' : '💤'}</span>
            </div>
            <div class="mt-2 bg-slate-900 px-3 py-1 rounded-full border border-white/10 opacity-0 group-hover:opacity-100 transition-opacity">
                <p class="text-[9px] font-black text-white whitespace-nowrap uppercase tracking-widest">${shop.name}</p>
            </div>
          </div>
        `,
        iconSize: [56, 56],
        iconAnchor: [28, 28]
      });
      const marker = L.marker([shop.position.x, shop.position.y], { icon, interactive: true, riseOnHover: true }).addTo(mapRef.current);
      marker.on('click', (e: any) => { L.DomEvent.stopPropagation(e); onOpenShop(shop); });
      shopsMarkersRef.current[shop.id] = marker;
    });
  }, [shops, onOpenShop, activeMarket?.id]);

  // Stable User Markers (No Math.random inside effect)
  useEffect(() => {
    if (!mapRef.current) return;
    // Fix: Cast to any to avoid "unknown" type error on remove() method when iterating values
    Object.values(usersMarkersRef.current).forEach(m => (m as any).remove());
    usersMarkersRef.current = {};
    
    otherUsers.forEach((user, idx) => {
      // Use fixed offsets based on index to spread users around if they have no set position
      const offsetLat = (idx % 10 - 5) * 0.0005;
      const offsetLng = (Math.floor(idx / 10) - 5) * 0.0005;
      const lat = user.position.x || (activeMarket?.lat ?? 31.52) + offsetLat;
      const lng = user.position.y || (activeMarket?.lng ?? 74.32) + offsetLng;
      
      const icon = L.divIcon({
        className: 'custom-div-icon',
        html: `
          <div class="group flex flex-col items-center -translate-y-1/2 cursor-pointer pointer-events-auto">
            <div class="relative avatar-marker">
                <div class="w-12 h-12 rounded-full border-4 border-indigo-400 shadow-2xl overflow-hidden bg-slate-800 hover:scale-125 transition-transform duration-300">
                    <img src="${user.avatarUrl}" class="w-full h-full object-cover" />
                </div>
            </div>
          </div>
        `,
        iconSize: [48, 48],
        iconAnchor: [24, 24]
      });
      const marker = L.marker([lat, lng], { icon, interactive: true }).addTo(mapRef.current);
      marker.on('click', (e: any) => { L.DomEvent.stopPropagation(e); onOpenChat(user); });
      usersMarkersRef.current[user.id] = marker;
    });
  }, [otherUsers, activeMarket?.id, onOpenChat]);

  // Stable Plot Layer
  useEffect(() => {
    if (!mapRef.current) return;
    if (plotsLayerRef.current) plotsLayerRef.current.clearLayers();
    else plotsLayerRef.current = L.layerGroup().addTo(mapRef.current);
    
    if (currentUser.role === UserRole.SHOPPER && !isSelectingPlot) return;
    
    plots.forEach(plot => {
        const isAvailable = !plot.isBooked;
        if (!isAvailable && !isSelectingPlot) return;
        
        const icon = L.divIcon({
          className: 'custom-div-icon',
          html: isAvailable ? `
            <div class="flex items-center justify-center w-10 h-10 group relative cursor-pointer pointer-events-auto">
              <div class="w-8 h-8 rounded-full bg-indigo-500/20 border-2 border-indigo-500 animate-pulse flex items-center justify-center">
                <div class="w-3 h-3 bg-indigo-500 rounded-full"></div>
              </div>
            </div>
          ` : `<div class="w-4 h-4 rounded-full bg-slate-700/30"></div>`,
          iconSize: [40, 40],
          iconAnchor: [20, 20]
        });
        const marker = L.marker([plot.x, plot.y], { icon, interactive: true }).addTo(plotsLayerRef.current);
        if (isAvailable && isSelectingPlot) {
            marker.on('click', (e: any) => { L.DomEvent.stopPropagation(e); if (onSelectPlot) onSelectPlot(plot); });
        }
    });
  }, [plots, isSelectingPlot, currentUser.role]);

  // Current User Marker - Optimized
  useEffect(() => {
    if (!mapRef.current || !currentUser) return;
    
    const avatarUrl = currentUser.avatarUrl;
    
    // Only recreate if marker doesn't exist
    if (!userMarkerRef.current) {
      const icon = L.divIcon({
          className: 'custom-div-icon',
          html: `<div class="relative avatar-marker group pointer-events-none scale-125"><div class="w-12 h-12 rounded-full border-4 border-indigo-600 shadow-2xl overflow-hidden bg-slate-900"><img src="${avatarUrl}" class="w-full h-full object-cover" /></div></div>`,
          iconSize: [48, 48], 
          iconAnchor: [24, 24]
      });
      userMarkerRef.current = L.marker(mapRef.current.getCenter(), { icon, zIndexOffset: 2000, interactive: false }).addTo(mapRef.current);
    } else {
      // Update icon only if url changed (avoid snapping to center if just balance changed)
      const icon = L.divIcon({
          className: 'custom-div-icon',
          html: `<div class="relative avatar-marker group pointer-events-none scale-125"><div class="w-12 h-12 rounded-full border-4 border-indigo-600 shadow-2xl overflow-hidden bg-slate-900"><img src="${avatarUrl}" class="w-full h-full object-cover" /></div></div>`,
          iconSize: [48, 48], 
          iconAnchor: [24, 24]
      });
      userMarkerRef.current.setIcon(icon);
    }

    const updatePos = () => { 
      if (userMarkerRef.current && mapRef.current) {
        userMarkerRef.current.setLatLng(mapRef.current.getCenter()); 
      }
    };
    
    mapRef.current.on('move', updatePos);
    return () => { if (mapRef.current) mapRef.current.off('move', updatePos); };
  }, [currentUser?.avatarUrl]); // Only depend on avatarUrl, not the entire user object (balance, etc.)

  return (
    <div className="w-full h-full relative overflow-hidden bg-slate-900">
        <div ref={containerRef} className="w-full h-full absolute inset-0 z-0" style={{ cursor: 'grab' }} />
        <div className="absolute top-6 left-6 z-[1000] pointer-events-none">
            <div className="bg-slate-900/90 backdrop-blur-xl p-5 rounded-[2rem] border border-white/10 shadow-2xl">
                <div className="flex items-center gap-4">
                    <div className="w-10 h-10 bg-indigo-500/20 rounded-2xl flex items-center justify-center">
                        <span className="text-indigo-400 text-lg animate-pulse">{activeMarket?.eventTheme === 'FESTIVE' ? '🏮' : '🛰️'}</span>
                    </div>
                    <div>
                        <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest leading-none mb-1">{activeMarket?.eventTheme === 'NEON' ? 'Neon Festival' : 'District Hub'}</p>
                        <p className="text-sm font-bold text-white">{activeMarket?.name || 'Locating...'}</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
  );
};
