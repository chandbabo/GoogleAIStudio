
import React, { useState, useEffect, useCallback, useMemo, useRef } from 'react';
import { User, UserRole, Shop, Product, Message, Order, Plot, Market, Notification } from './types';
import { AvatarCreator } from './components/AvatarCreator';
import { VirtualWorld } from './components/VirtualWorld';
import { ShopModal } from './components/ShopModal';
import { Chat } from './components/Chat';
import { OwnerDashboard } from './components/OwnerDashboard';
import { AdminDashboard } from './components/AdminDashboard';
import { db } from './services/db';

const App: React.FC = () => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [userRole, setUserRole] = useState<UserRole | null>(null);
  const [step, setStep] = useState<'AUTH_CHOICE' | 'LOGIN' | 'ADMIN_LOGIN' | 'SIGNUP' | 'AVATAR' | 'LAND_SELECTION' | 'WORLD'>('AUTH_CHOICE');
  const [formData, setFormData] = useState({ name: '', phone: '' });
  const [isSigningIn, setIsSigningIn] = useState(true);
  
  const [markets, setMarkets] = useState<Market[]>([]);
  const [activeMarket, setActiveMarket] = useState<Market | null>(null);
  const [allShops, setAllShops] = useState<Shop[]>([]);
  const [allUsers, setAllUsers] = useState<User[]>([]);
  const [activeShop, setActiveShop] = useState<Shop | null>(null);
  const [activeChat, setActiveChat] = useState<User | null>(null);
  const [isOwnerDashOpen, setIsOwnerDashOpen] = useState(false);
  const [isAdminDashOpen, setIsAdminDashOpen] = useState(false);
  const [selectedPlot, setSelectedPlot] = useState<Plot | null>(null);
  
  const [plots, setPlots] = useState<Plot[]>([]);
  const [allMessages, setAllMessages] = useState<Message[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [notifications, setNotifications] = useState<Notification[]>([]);

  const [searchQuery, setSearchQuery] = useState('');
  const [userCoords, setUserCoords] = useState<{ lat: number, lng: number } | null>(null);
  const hasInitialized = useRef(false);

  const refreshData = useCallback(async () => {
    const [fetchedMarkets, fetchedShops, fetchedUsers, fetchedOrders, fetchedPlots, fetchedMessages] = await Promise.all([
      db.markets.getAll(),
      db.shops.getAll(),
      db.users.getAll(),
      db.orders.getAll(),
      db.plots.getAll(),
      db.messages.getAll()
    ]);

    setMarkets(fetchedMarkets);
    setAllShops(fetchedShops);
    setAllUsers(fetchedUsers);
    setOrders(fetchedOrders);
    setPlots(fetchedPlots);
    setAllMessages(fetchedMessages);
    
    if (currentUser) {
      const fetchedNotifs = await db.notifications.getByUserId(currentUser.id);
      setNotifications(fetchedNotifs);
    }
  }, [currentUser?.id]);

  const calculateDistance = (lat1: number, lon1: number, lat2: number, lon2: number) => {
    const R = 6371;
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLon = (lon2 - lon1) * Math.PI / 180;
    const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
              Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * 
              Math.sin(dLon/2) * Math.sin(dLon/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    return R * c;
  };

  useEffect(() => {
    if (hasInitialized.current) return;
    hasInitialized.current = true;

    const init = async () => {
      await db.initialize();
      await refreshData();

      navigator.geolocation.getCurrentPosition((pos) => {
        const coords = { lat: pos.coords.latitude, lng: pos.coords.longitude };
        setUserCoords(coords);
        db.markets.getAll().then(allMarkets => {
          if (allMarkets.length > 0) {
            const nearest = allMarkets.reduce((prev, curr) => {
                const dPrev = calculateDistance(coords.lat, coords.lng, prev.lat, prev.lng);
                const dCurr = calculateDistance(coords.lat, coords.lng, curr.lat, curr.lng);
                return dCurr < dPrev ? prev : curr;
            });
            setActiveMarket(nearest);
          }
        });
      }, () => {
          db.markets.getAll().then(allMarkets => {
            if (allMarkets.length > 0) setActiveMarket(allMarkets[0]);
          });
      });

      const sessionId = db.auth.getSessionId();
      if (sessionId) {
        const user = await db.users.getById(sessionId);
        if (user) {
          setCurrentUser(user);
          const shops = await db.shops.getAll();
          const userShops = shops.filter(s => s.ownerId === user.id);
          if (user.role === UserRole.OWNER && userShops.length === 0) {
            setStep('LAND_SELECTION');
          } else {
            setStep('WORLD');
            if (user.role === UserRole.OWNER) setIsOwnerDashOpen(true);
            if (user.role === UserRole.ADMIN) setIsAdminDashOpen(true);
          }
        }
      }
    };
    init();
  }, []); // Run only once on mount

  const handleSignOut = () => {
    db.auth.clearSession();
    setCurrentUser(null);
    setUserRole(null);
    setStep('AUTH_CHOICE');
    setIsOwnerDashOpen(false);
    setIsAdminDashOpen(false);
  };

  const handleLoginSubmit = async (e: React.FormEvent, isAdminAttempt: boolean = false) => {
    e.preventDefault();
    const users = await db.users.getAll();
    const user = users.find(u => u.phone === formData.phone);
    if (user) {
      if (isAdminAttempt && user.role !== UserRole.ADMIN) {
        alert("Access Denied: Administrative credentials required.");
        return;
      }
      setCurrentUser(user);
      db.auth.setSessionId(user.id);
      const shops = await db.shops.getAll();
      const userShops = shops.filter(s => s.ownerId === user.id);
      if (user.role === UserRole.OWNER && userShops.length === 0) {
        setStep('LAND_SELECTION');
      } else {
        setStep('WORLD');
        if (user.role === UserRole.OWNER) setIsOwnerDashOpen(true);
        if (user.role === UserRole.ADMIN) setIsAdminDashOpen(true);
      }
    } else {
      alert("No account found. Please check your credentials.");
    }
  };

  const finalizeProfile = async (avatarUrl: string) => {
    const userId = Math.random().toString(36).substr(2, 9);
    const newUser: User = {
      id: userId,
      name: formData.name,
      phone: formData.phone,
      role: userRole!,
      avatarUrl,
      position: { x: activeMarket?.lat || 0, y: activeMarket?.lng || 0 },
      balance: 5000
    };
    await db.users.create(newUser);
    db.auth.setSessionId(userId);
    setCurrentUser(newUser);
    await refreshData();
    if (userRole === UserRole.OWNER) setStep('LAND_SELECTION');
    else setStep('WORLD');
  };

  const handleConfirmPurchase = async () => {
    if (!currentUser || !selectedPlot) return;
    const shopId = `shop_${Date.now()}`;
    const newShop: Shop = {
      id: shopId,
      marketId: selectedPlot.marketId,
      name: `${currentUser.name}'s Boutique`,
      ownerId: currentUser.id,
      category: 'General',
      products: [],
      position: { x: selectedPlot.x, y: selectedPlot.y },
      color: 'bg-indigo-600',
      plotId: selectedPlot.id,
      status: 'PENDING',
      isActive: false,
      likes: 0
    };
    await db.shops.create(newShop);
    await db.plots.update(selectedPlot.id, { isBooked: true, ownerId: currentUser.id });
    await refreshData();
    setSelectedPlot(null);
    setStep('WORLD');
    setIsOwnerDashOpen(true);
  };

  const handleCreateMarket = async (name: string, lat: number, lng: number) => {
    const id = `market_${Date.now()}`;
    const newMarket: Market = { id, name, lat, lng, description: `District: ${name}`, radius: 100 };
    await db.markets.create(newMarket);
    await refreshData();
    setActiveMarket(newMarket);
    setIsAdminDashOpen(false);
  };

  const marketShops = useMemo(() => {
    if (!currentUser) return [];
    if (currentUser.role === UserRole.SHOPPER) {
      return allShops.filter(s => s.marketId === activeMarket?.id && s.status === 'APPROVED' && s.isActive);
    }
    return allShops.filter(s => s.marketId === activeMarket?.id);
  }, [allShops, activeMarket?.id, currentUser?.role]);

  const marketPlots = useMemo(() => plots.filter(p => p.marketId === activeMarket?.id), [plots, activeMarket?.id]);

  const otherUsers = useMemo(() => {
    if (!currentUser) return [];
    return allUsers.filter(u => u.id !== currentUser.id);
  }, [allUsers, currentUser?.id]);

  const searchResults = useMemo(() => {
    if (!searchQuery.trim()) return { shops: [], markets: [] };
    const q = searchQuery.toLowerCase();
    const filteredShops = allShops.filter(s => (s.name.toLowerCase().includes(q) || s.category.toLowerCase().includes(q)) && s.status === 'APPROVED' && s.isActive);
    const filteredMarkets = markets.filter(m => m.name.toLowerCase().includes(q));
    return { shops: filteredShops, markets: filteredMarkets };
  }, [searchQuery, allShops, markets]);

  const handleNavigateToResult = (item: Shop | Market) => {
    if ('marketId' in item) {
        const targetMarket = markets.find(m => m.id === (item as Shop).marketId);
        if (targetMarket) setActiveMarket(targetMarket);
    } else {
        setActiveMarket(item as Market);
    }
    setSearchQuery('');
  };

  // Auth Screens
  if (step === 'AUTH_CHOICE') {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center p-6 bg-[#020617] text-white">
        <h1 className="text-8xl font-black mb-16 tracking-tighter filter drop-shadow-[0_0_40px_rgba(99,102,241,0.2)]">Shop<span className="text-indigo-400">Verse</span></h1>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl w-full">
          <button onClick={() => setStep('LOGIN')} className="p-10 bg-indigo-600/10 border-2 border-indigo-500/20 rounded-[3rem] text-center hover:bg-indigo-600/20 hover:border-indigo-500/50 transition-all group">
            <div className="text-5xl mb-6">👤</div>
            <h3 className="text-3xl font-black mb-2">User Portal</h3>
            <p className="text-indigo-200/60 font-medium">Join as Shopper or Business Owner</p>
          </button>
          <button onClick={() => setStep('ADMIN_LOGIN')} className="p-10 bg-emerald-600/10 border-2 border-emerald-500/20 rounded-[3rem] text-center hover:bg-emerald-600/20 hover:border-emerald-500/50 transition-all group">
            <div className="text-5xl mb-6">🔑</div>
            <h3 className="text-3xl font-black mb-2">Admin Terminal</h3>
            <p className="text-emerald-200/60 font-medium">District Management & Clearances</p>
          </button>
        </div>
      </div>
    );
  }

  if (step === 'LOGIN' || step === 'ADMIN_LOGIN' || step === 'SIGNUP') {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center p-6 bg-[#020617] text-white">
        <h1 className="text-6xl font-black mb-12 tracking-tighter cursor-pointer" onClick={() => setStep('AUTH_CHOICE')}>Shop<span className="text-indigo-400">Verse</span></h1>
        
        {(step === 'LOGIN' || step === 'ADMIN_LOGIN') && isSigningIn && (
           <div className="w-full max-w-md bg-white p-10 rounded-[3rem] shadow-2xl text-slate-900">
              <h2 className="text-3xl font-black mb-2 text-center">{step === 'ADMIN_LOGIN' ? 'Admin Terminal' : 'User Access'}</h2>
              <p className="text-slate-400 text-sm mb-8 text-center font-bold uppercase tracking-widest">Global Market Entry</p>
              <form onSubmit={(e) => handleLoginSubmit(e, step === 'ADMIN_LOGIN')} className="space-y-6">
                  <input required type="tel" value={formData.phone} onChange={e => setFormData({...formData, phone: e.target.value})} placeholder="Phone Number" className="w-full p-5 bg-slate-100 rounded-3xl border-none outline-none font-bold text-lg" />
                  <button type="submit" className={`w-full py-5 ${step === 'ADMIN_LOGIN' ? 'bg-emerald-600' : 'bg-indigo-600'} text-white rounded-3xl font-black text-lg shadow-xl hover:opacity-90 transition-all`}>Continue</button>
                  {step !== 'ADMIN_LOGIN' && <button type="button" onClick={() => setIsSigningIn(false)} className="w-full text-xs font-black text-slate-400 uppercase tracking-widest text-center">New to the Verse? Sign Up</button>}
                  <button type="button" onClick={() => setStep('AUTH_CHOICE')} className="w-full text-[10px] font-black text-slate-300 uppercase tracking-widest text-center">Return to Choice</button>
              </form>
           </div>
        )}

        {step === 'LOGIN' && !isSigningIn && (
           <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl w-full">
              <button onClick={() => {setUserRole(UserRole.SHOPPER); setStep('SIGNUP')}} className="p-10 bg-white text-slate-900 rounded-[3rem] text-left hover:scale-[1.02] transition-all shadow-xl group">
                  <div className="text-4xl mb-6">🛒</div>
                  <h3 className="text-2xl font-black mb-2">Shopper</h3>
                  <p className="text-slate-500 font-medium">Explore and buy products across the map.</p>
              </button>
              <button onClick={() => {setUserRole(UserRole.OWNER); setStep('SIGNUP')}} className="p-10 bg-white text-slate-900 rounded-[3rem] text-left hover:scale-[1.02] transition-all shadow-xl group">
                  <div className="text-4xl mb-6">💼</div>
                  <h3 className="text-2xl font-black mb-2">Shop Owner</h3>
                  <p className="text-slate-500 font-medium">Own real estate and build your digital empire.</p>
              </button>
              <button onClick={() => setIsSigningIn(true)} className="md:col-span-2 py-5 bg-white/5 border border-white/10 rounded-3xl font-black text-xs uppercase tracking-widest">Already have an account? Sign In</button>
           </div>
        )}

        {step === 'SIGNUP' && (
           <div className="fixed inset-0 bg-slate-950/90 backdrop-blur-md z-[100] flex items-center justify-center p-6">
               <form onSubmit={(e) => {e.preventDefault(); setStep('AVATAR')}} className="bg-white p-10 rounded-[3rem] text-slate-900 w-full max-w-md space-y-6 animate-in slide-in-from-bottom-10">
                   <h2 className="text-3xl font-black text-center">Create Profile</h2>
                   <input required placeholder="Full Name" value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} className="w-full p-5 bg-slate-50 rounded-2xl outline-none font-bold text-lg" />
                   <input required placeholder="Phone Number" value={formData.phone} onChange={e => setFormData({...formData, phone: e.target.value})} className="w-full p-5 bg-slate-50 rounded-2xl outline-none font-bold text-lg" />
                   <button type="submit" className="w-full py-5 bg-indigo-600 text-white rounded-2xl font-black text-lg shadow-lg hover:bg-indigo-700">Next: Personalize Avatar</button>
                   <button type="button" onClick={() => setStep('LOGIN')} className="w-full text-xs font-black text-slate-400 uppercase tracking-widest text-center">Cancel</button>
               </form>
           </div>
        )}
      </div>
    );
  }

  if (step === 'AVATAR') return <div className="min-h-screen bg-[#020617] flex items-center justify-center p-6"><AvatarCreator onAvatarComplete={finalizeProfile} /></div>;

  return (
    <div className="h-screen w-full relative flex flex-col overflow-hidden bg-slate-950">
      <nav className="h-20 bg-slate-900/95 backdrop-blur-xl border-b border-white/10 px-8 flex items-center justify-between z-[2000] text-white">
        <div className="flex items-center gap-8">
          <div className="flex flex-col cursor-pointer" onClick={() => { if(currentUser?.role === UserRole.ADMIN) setIsAdminDashOpen(true); }}>
            <span className="text-2xl font-black leading-none tracking-tighter">Shop<span className="text-indigo-400">Verse</span></span>
            <span className="text-[10px] text-white/40 font-black uppercase tracking-[0.2em] mt-1">{activeMarket?.name || 'Locating...'}</span>
          </div>
          <div className="relative w-80 group">
            <input type="text" placeholder="Search Approved Shops..." value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} className="w-full bg-white/5 border border-white/10 rounded-2xl pl-12 pr-4 py-3 text-sm outline-none focus:bg-white/10 focus:border-indigo-500/50 transition-all font-medium" />
            {searchQuery && (
                <div className="absolute top-full mt-3 left-0 w-full bg-slate-900 border border-white/10 rounded-3xl shadow-2xl p-2 space-y-1 overflow-hidden">
                    {searchResults.markets.map(m => (
                        <button key={m.id} onClick={() => handleNavigateToResult(m)} className="w-full text-left p-4 hover:bg-white/5 rounded-2xl flex items-center gap-4 transition-colors">
                            <span className="text-xl">📍</span>
                            <div><p className="text-sm font-bold text-white">{m.name}</p></div>
                        </button>
                    ))}
                    {searchResults.shops.map(s => (
                        <button key={s.id} onClick={() => handleNavigateToResult(s)} className="w-full text-left p-4 hover:bg-white/5 rounded-2xl flex items-center gap-4 transition-colors">
                            <span className="text-xl">🏪</span>
                            <div><p className="text-sm font-bold text-white">{s.name}</p></div>
                        </button>
                    ))}
                </div>
            )}
          </div>
        </div>
        <div className="flex items-center gap-6">
          <div className="relative group">
            <button className="p-2 bg-white/5 rounded-xl hover:bg-white/10 transition-all relative">
              <span className="text-xl">🔔</span>
              {notifications.some(n => !n.isRead) && <span className="absolute top-2 right-2 w-2 h-2 bg-rose-500 rounded-full border-2 border-slate-900"></span>}
            </button>
            <div className="absolute top-full right-0 mt-2 w-64 bg-slate-900 border border-white/10 rounded-2xl p-4 shadow-2xl opacity-0 group-hover:opacity-100 pointer-events-none group-hover:pointer-events-auto transition-all">
              <p className="text-[10px] font-black uppercase tracking-widest text-slate-500 mb-3">Recent Notifications</p>
              <div className="space-y-3">
                {notifications.slice(0, 5).map(n => (
                  <div key={n.id} className="text-xs">
                    <p className="font-bold text-white">{n.title}</p>
                    <p className="text-slate-400 leading-tight">{n.message}</p>
                  </div>
                ))}
                {notifications.length === 0 && <p className="text-slate-500 text-[10px] text-center italic">No new activity</p>}
              </div>
            </div>
          </div>
          {currentUser?.role === UserRole.ADMIN && <button onClick={() => setIsAdminDashOpen(true)} className="px-6 py-3 bg-emerald-500 text-white rounded-2xl text-xs font-black uppercase tracking-widest">Admin Dashboard</button>}
          {currentUser?.role === UserRole.OWNER && <button onClick={() => setIsOwnerDashOpen(true)} className="px-6 py-3 bg-indigo-600 rounded-2xl text-xs font-black uppercase tracking-widest hover:bg-indigo-700 transition-colors">Business Office</button>}
          <div className="h-10 w-px bg-white/10"></div>
          <div className="flex items-center gap-4">
             <div className="flex flex-col items-end">
                <span className="text-sm font-black text-white">{currentUser?.name}</span>
                <span className="text-[9px] text-indigo-400 font-black uppercase tracking-widest">{currentUser?.role}</span>
             </div>
             <img src={currentUser?.avatarUrl} className="w-11 h-11 rounded-full border-2 border-white/20 shadow-xl" />
             <button onClick={handleSignOut} className="p-2.5 bg-rose-500/10 text-rose-500 rounded-xl hover:bg-rose-500/20 transition-colors"><svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" /></svg></button>
          </div>
        </div>
      </nav>

      <div className="flex-1 relative">
        <VirtualWorld 
          currentUser={currentUser!} 
          onOpenShop={setActiveShop} 
          onOpenChat={setActiveChat} 
          shops={marketShops} 
          plots={marketPlots} 
          otherUsers={otherUsers}
          activeMarket={activeMarket} 
          onSelectPlot={(p) => setSelectedPlot(p)} 
          isSelectingPlot={step === 'LAND_SELECTION'} 
        />
      </div>

      {selectedPlot && (
        <div className="fixed inset-0 z-[4000] flex items-center justify-center p-6">
          <div className="absolute inset-0 bg-slate-950/60 backdrop-blur-md" onClick={() => setSelectedPlot(null)}></div>
          <div className="relative bg-white w-full max-md p-10 rounded-[3rem] text-slate-900 space-y-6 animate-in zoom-in">
             <div className="text-center">
                <div className="w-20 h-20 bg-indigo-50 text-indigo-600 rounded-3xl flex items-center justify-center text-4xl mx-auto mb-6">🏘️</div>
                <h3 className="text-3xl font-black">Commercial Deed</h3>
                <p className="text-slate-500 font-bold mt-1">Acquisition Price: <span className="text-indigo-600 font-black">${selectedPlot.price}</span></p>
             </div>
             <p className="text-sm text-slate-500 text-center font-medium leading-relaxed">Purchasing this plot will send a formal request to the District Admin for trade clearance.</p>
             <div className="flex flex-col gap-3">
                <button onClick={handleConfirmPurchase} className="w-full py-5 bg-indigo-600 text-white rounded-2xl font-black text-lg shadow-xl">Pay & Request Approval</button>
                <button onClick={() => setSelectedPlot(null)} className="w-full py-3 text-slate-400 font-black uppercase text-xs tracking-widest">Cancel</button>
             </div>
          </div>
        </div>
      )}

      {isAdminDashOpen && <AdminDashboard onClose={() => setIsAdminDashOpen(false)} onRefresh={refreshData} onEstablishMarket={handleCreateMarket} userCoords={userCoords} />}
      {activeShop && <ShopModal currentUser={currentUser!} shop={activeShop} onClose={() => setActiveShop(null)} onAddToCart={() => {}} onChatWithOwner={async () => { const owner = await db.users.getById(activeShop.ownerId); if (owner) { setActiveChat(owner); setActiveShop(null); } }} onRefresh={refreshData} />}
      {activeChat && <Chat currentUser={currentUser!} targetUser={activeChat} shopContext={allShops.find(s => s.ownerId === activeChat.id)?.name} onClose={() => setActiveChat(null)} onNewMessage={async msg => { await db.messages.create(msg); await refreshData(); }} />}
      {isOwnerDashOpen && <OwnerDashboard shop={allShops.find(s => s.ownerId === currentUser?.id) || null} orders={orders} allMessages={allMessages} notifications={notifications.filter(n => !n.isRead)} onUpdateShop={async s => { await db.shops.update(s.id, s); await refreshData(); }} onClose={() => setIsOwnerDashOpen(false)} onOpenChat={async uid => { const u = await db.users.getById(uid); if (u) { setActiveChat(u); setIsOwnerDashOpen(false); } }} onEnterMapMode={() => { setStep('LAND_SELECTION'); setIsOwnerDashOpen(false); }} onSignOut={handleSignOut} />}
    </div>
  );
};

export default App;
