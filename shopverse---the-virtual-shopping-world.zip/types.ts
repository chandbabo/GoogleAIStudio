
export enum UserRole {
  SHOPPER = 'SHOPPER',
  OWNER = 'OWNER',
  ADMIN = 'ADMIN'
}

export interface Market {
  id: string;
  name: string;
  lat: number;
  lng: number;
  description: string;
  radius: number;
  eventTheme?: 'NEON' | 'FESTIVE' | 'GOLD' | 'NORMAL';
}

export interface User {
  id: string;
  name: string;
  phone: string;
  role: UserRole;
  avatarUrl: string;
  position: { x: number; y: number };
  currentMarketId?: string;
  balance: number;
}

export interface Product {
  id: string;
  name: string;
  price: number;
  description: string;
  imageUrl: string;
  category: string;
  ownerId: string;
  timestamp: number;
}

export interface Order {
  id: string;
  shopId: string;
  customerName: string;
  customerPhone: string;
  items: Product[];
  total: number;
  status: 'PENDING' | 'COMPLETED';
  timestamp: number;
}

export interface Plot {
  id: string;
  marketId: string;
  x: number;
  y: number;
  price: number;
  isBooked: boolean;
  ownerId?: string;
  trafficCount: number;
}

export interface Shop {
  id: string;
  marketId: string;
  name: string;
  ownerId: string;
  category: string;
  products: Product[];
  position: { x: number; y: number };
  color: string;
  plotId?: string;
  status: 'PENDING' | 'APPROVED' | 'REJECTED';
  isActive: boolean;
  likes: number;
  assistantInstructions?: string;
}

export interface Review {
  id: string;
  shopId: string;
  userId: string;
  userName: string;
  rating: number;
  comment: string;
  timestamp: number;
}

export interface Message {
  id: string;
  senderId: string;
  receiverId: string;
  text: string;
  timestamp: number;
  isRead?: boolean;
  isAI?: boolean;
}

export interface Notification {
  id: string;
  userId: string;
  title: string;
  message: string;
  type: 'INFO' | 'SUCCESS' | 'ALERT';
  timestamp: number;
  isRead: boolean;
}

export interface Follow {
  id: string;
  shopperId: string;
  ownerId: string;
}

export interface RentTransaction {
  id: string;
  shopId: string;
  amount: number;
  timestamp: number;
  reason: string;
}
