
import { GoogleGenAI } from "@google/genai";

export class GeminiService {
  async generateAvatarDescription(base64Image: string): Promise<string> {
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: {
          parts: [
            { inlineData: { data: base64Image, mimeType: 'image/jpeg' } },
            { text: "Describe this person's key features (hair color, style, eyes, glasses, facial hair) in 5 keywords for a 3D cartoon avatar generation." }
          ]
        },
        config: { thinkingConfig: { thinkingBudget: 0 } }
      });
      return response.text || "Friendly Shopper";
    } catch (error) {
      return "Default Character";
    }
  }

  async generateAvatarImage(description: string): Promise<string> {
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash-image',
        contents: {
          parts: [{ text: `A vibrant, high-quality 3D cartoon character avatar, head and shoulders, looking at camera, based on: ${description}. Soft lighting, clean background, Pixar style.` }]
        },
        config: { imageConfig: { aspectRatio: "1:1" } }
      });

      if (response.candidates && response.candidates[0].content.parts) {
        for (const part of response.candidates[0].content.parts) {
          if (part.inlineData) {
            const base64EncodeString: string = part.inlineData.data;
            return `data:image/png;base64,${base64EncodeString}`;
          }
        }
      }
      return `https://picsum.photos/seed/${Math.random()}/200`;
    } catch (error) {
      return `https://picsum.photos/seed/default/200`;
    }
  }

  async chatResponse(history: {role: string, parts: {text: string}[]}[], userMsg: string, context?: string): Promise<string> {
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: [...history, { role: 'user', parts: [{ text: userMsg }] }],
        config: {
            systemInstruction: context || "You are a friendly fellow shopper in a virtual world called ShopVerse. Keep responses brief and conversational.",
            thinkingConfig: { thinkingBudget: 0 }
        }
      });
      return response.text || "That sounds cool!";
    } catch (error) {
      return "I agree!";
    }
  }

  async assistantResponse(shopName: string, shopDesc: string, products: any[], userMsg: string): Promise<string> {
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const productList = products.map(p => `${p.name} ($${p.price})`).join(', ');
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `I am a customer at "${shopName}". ${shopDesc}. Our current products are: ${productList}. Customer asks: "${userMsg}". Answer briefly as a helpful AI shop assistant.`,
        config: { thinkingConfig: { thinkingBudget: 0 } }
      });
      return response.text || "How can I help you today?";
    } catch (error) {
      return "I'm currently busy, but please check our catalogue!";
    }
  }
}

export const gemini = new GeminiService();
