
import { User, Shop, Plot, Order, Message, Market, UserRole, Review, Notification, Follow, RentTransaction } from '../types';

const STORAGE_KEYS = {
  USERS: 'shopverse_users',
  SHOPS: 'shopverse_shops',
  PLOTS: 'shopverse_plots',
  ORDERS: 'shopverse_orders',
  MESSAGES: 'shopverse_messages',
  MARKETS: 'shopverse_markets',
  REVIEWS: 'shopverse_reviews',
  NOTIFICATIONS: 'shopverse_notifications',
  FOLLOWS: 'shopverse_follows',
  RENT: 'shopverse_rent',
  SESSION: 'shopverse_session_id'
};

class DBService {
  private get<T>(key: string): T[] {
    const data = localStorage.getItem(key);
    return data ? JSON.parse(data) : [];
  }

  private set<T>(key: string, data: T[]): void {
    localStorage.setItem(key, JSON.stringify(data));
  }

  auth = {
    getSessionId: () => localStorage.getItem(STORAGE_KEYS.SESSION),
    setSessionId: (id: string) => localStorage.setItem(STORAGE_KEYS.SESSION, id),
    clearSession: () => localStorage.removeItem(STORAGE_KEYS.SESSION)
  };

  users = {
    getAll: async (): Promise<User[]> => this.get<User>(STORAGE_KEYS.USERS),
    getById: async (id: string): Promise<User | undefined> => this.get<User>(STORAGE_KEYS.USERS).find(u => u.id === id),
    create: async (user: User): Promise<void> => {
      const users = this.get<User>(STORAGE_KEYS.USERS);
      users.push({ ...user, balance: user.balance || 5000 });
      this.set(STORAGE_KEYS.USERS, users);
    },
    update: async (id: string, updates: Partial<User>): Promise<void> => {
      const users = this.get<User>(STORAGE_KEYS.USERS).map(u => u.id === id ? { ...u, ...updates } : u);
      this.set(STORAGE_KEYS.USERS, users);
    }
  };

  shops = {
    getAll: async (): Promise<Shop[]> => this.get<Shop>(STORAGE_KEYS.SHOPS),
    getById: async (id: string): Promise<Shop | undefined> => this.get<Shop>(STORAGE_KEYS.SHOPS).find(s => s.id === id),
    create: async (shop: Shop): Promise<void> => {
      const shops = this.get<Shop>(STORAGE_KEYS.SHOPS);
      shops.push(shop);
      this.set(STORAGE_KEYS.SHOPS, shops);
    },
    update: async (id: string, updates: Partial<Shop>): Promise<void> => {
      const shops = this.get<Shop>(STORAGE_KEYS.SHOPS).map(s => s.id === id ? { ...s, ...updates } : s);
      this.set(STORAGE_KEYS.SHOPS, shops);
    },
    like: async (shopId: string): Promise<void> => {
      const shops = this.get<Shop>(STORAGE_KEYS.SHOPS).map(s => s.id === shopId ? { ...s, likes: (s.likes || 0) + 1 } : s);
      this.set(STORAGE_KEYS.SHOPS, shops);
    },
    recordVisit: async (shopId: string): Promise<void> => {
      const shop = (await this.shops.getAll()).find(s => s.id === shopId);
      if (shop?.plotId) {
        const plots = this.get<Plot>(STORAGE_KEYS.PLOTS).map(p => 
          p.id === shop.plotId ? { ...p, trafficCount: (p.trafficCount || 0) + 1 } : p
        );
        this.set(STORAGE_KEYS.PLOTS, plots);
      }
    }
  };

  markets = {
    getAll: async (): Promise<Market[]> => this.get<Market>(STORAGE_KEYS.MARKETS),
    create: async (market: Market): Promise<void> => {
      const markets = this.get<Market>(STORAGE_KEYS.MARKETS);
      markets.push(market);
      this.set(STORAGE_KEYS.MARKETS, markets);
    },
    update: async (id: string, updates: Partial<Market>): Promise<void> => {
      const markets = this.get<Market>(STORAGE_KEYS.MARKETS).map(m => m.id === id ? { ...m, ...updates } : m);
      this.set(STORAGE_KEYS.MARKETS, markets);
    }
  };

  plots = {
    getAll: async (): Promise<Plot[]> => this.get<Plot>(STORAGE_KEYS.PLOTS),
    update: async (id: string, updates: Partial<Plot>): Promise<void> => {
      const plots = this.get<Plot>(STORAGE_KEYS.PLOTS).map(p => p.id === id ? { ...p, ...updates } : p);
      this.set(STORAGE_KEYS.PLOTS, plots);
    }
  };

  follows = {
    getFollowers: async (ownerId: string): Promise<Follow[]> => this.get<Follow>(STORAGE_KEYS.FOLLOWS).filter(f => f.ownerId === ownerId),
    toggleFollow: async (shopperId: string, ownerId: string): Promise<void> => {
      let follows = this.get<Follow>(STORAGE_KEYS.FOLLOWS);
      const existing = follows.find(f => f.shopperId === shopperId && f.ownerId === ownerId);
      if (existing) {
        follows = follows.filter(f => f.id !== existing.id);
      } else {
        follows.push({ id: `f_${Date.now()}`, shopperId, ownerId });
      }
      this.set(STORAGE_KEYS.FOLLOWS, follows);
    },
    isFollowing: async (shopperId: string, ownerId: string): Promise<boolean> => 
      !!this.get<Follow>(STORAGE_KEYS.FOLLOWS).find(f => f.shopperId === shopperId && f.ownerId === ownerId)
  };

  rent = {
    getHistory: async (shopId: string): Promise<RentTransaction[]> => this.get<RentTransaction>(STORAGE_KEYS.RENT).filter(r => r.shopId === shopId),
    collectRent: async (shopId: string): Promise<number> => {
      const shops = await this.shops.getAll();
      const shop = shops.find(s => s.id === shopId);
      if (!shop || !shop.plotId) return 0;
      
      const plot = (await this.plots.getAll()).find(p => p.id === shop.plotId);
      if (!plot) return 0;

      const trafficFee = (plot.trafficCount || 0) * 0.5;
      const baseRent = plot.price * 0.05;
      const totalRent = Math.floor(baseRent + trafficFee);

      if (totalRent > 0) {
        const transactions = this.get<RentTransaction>(STORAGE_KEYS.RENT);
        transactions.push({
          id: `rent_${Date.now()}`,
          shopId,
          amount: totalRent,
          timestamp: Date.now(),
          reason: `Auto-rent: Base(${baseRent.toFixed(0)}) + Traffic(${trafficFee.toFixed(0)})`
        });
        this.set(STORAGE_KEYS.RENT, transactions);

        // Deduct from owner
        const owner = await this.users.getById(shop.ownerId);
        if (owner) {
          await this.users.update(owner.id, { balance: (owner.balance || 0) - totalRent });
        }

        // Reset traffic for next cycle
        await this.plots.update(plot.id, { trafficCount: 0 });
      }
      return totalRent;
    }
  };

  reviews = {
    getByShopId: async (shopId: string): Promise<Review[]> => this.get<Review>(STORAGE_KEYS.REVIEWS).filter(r => r.shopId === shopId),
    create: async (review: Review): Promise<void> => {
      const reviews = this.get<Review>(STORAGE_KEYS.REVIEWS);
      reviews.push(review);
      this.set(STORAGE_KEYS.REVIEWS, reviews);
    }
  };

  messages = {
    getAll: async (): Promise<Message[]> => this.get<Message>(STORAGE_KEYS.MESSAGES),
    create: async (msg: Message): Promise<void> => {
      const msgs = this.get<Message>(STORAGE_KEYS.MESSAGES);
      msgs.push(msg);
      this.set(STORAGE_KEYS.MESSAGES, msgs);
    }
  };

  notifications = {
    getByUserId: async (userId: string): Promise<Notification[]> => this.get<Notification>(STORAGE_KEYS.NOTIFICATIONS).filter(n => n.userId === userId),
    create: async (notif: Notification): Promise<void> => {
      const notifs = this.get<Notification>(STORAGE_KEYS.NOTIFICATIONS);
      notifs.push(notif);
      this.set(STORAGE_KEYS.NOTIFICATIONS, notifs);
    },
    markRead: async (id: string): Promise<void> => {
      const notifs = this.get<Notification>(STORAGE_KEYS.NOTIFICATIONS).map(n => n.id === id ? { ...n, isRead: true } : n);
      this.set(STORAGE_KEYS.NOTIFICATIONS, notifs);
    }
  };

  orders = {
    getAll: async (): Promise<Order[]> => this.get<Order>(STORAGE_KEYS.ORDERS),
    create: async (order: Order): Promise<void> => {
      const orders = this.get<Order>(STORAGE_KEYS.ORDERS);
      orders.push(order);
      this.set(STORAGE_KEYS.ORDERS, orders);
    }
  };

  async initialize() {
    if ((await this.users.getAll()).length === 0) {
      await this.users.create({
        id: 'admin_1',
        name: 'ShopVerse Admin',
        phone: '000',
        role: UserRole.ADMIN,
        avatarUrl: 'https://picsum.photos/seed/admin/200',
        position: { x: 0, y: 0 },
        balance: 999999
      });
    }

    if ((await this.markets.getAll()).length === 0) {
      const defaultMarkets: Market[] = [
        { id: 'm1', name: 'Ichhra Market', lat: 31.5204, lng: 74.3275, description: 'Traditional bazaar.', radius: 100, eventTheme: 'FESTIVE' },
        { id: 'm2', name: 'Liberty Square', lat: 31.5113, lng: 74.3415, description: 'Modern hub.', radius: 100, eventTheme: 'NEON' }
      ];
      this.set(STORAGE_KEYS.MARKETS, defaultMarkets);
      for (const m of defaultMarkets) {
        await this.createMarketPlots(m.id, m.lat, m.lng);
      }
    }
  }

  private async createMarketPlots(marketId: string, centerLat: number, centerLng: number) {
    const initialPlots: Plot[] = [];
    const step = 0.0004;
    const gridCount = 6;
    for (let i = -gridCount; i <= gridCount; i++) {
      for (let j = -gridCount; j <= gridCount; j++) {
        const x = centerLat + (i * step);
        const y = centerLng + (j * step);
        if (Math.random() > 0.7) continue;
        const dist = Math.sqrt(i * i + j * j);
        const price = Math.max(100, Math.floor(2000 * (1 - dist / (gridCount * 1.5))));
        initialPlots.push({ id: `${marketId}_plot_${i}_${j}`, marketId, x, y, price, isBooked: false, trafficCount: 0 });
      }
    }
    const existing = await this.plots.getAll();
    this.set(STORAGE_KEYS.PLOTS, [...existing, ...initialPlots]);
  }
}

export const db = new DBService();
